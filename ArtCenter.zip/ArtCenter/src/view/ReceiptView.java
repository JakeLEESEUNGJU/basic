package view;

public class ReceiptView {

	public ReceiptView() {
		addLayout();
		connectDB();
		eventProc();
	}

	void eventProc() {

	}

	void addLayout() {

	}

	void connectDB() {

	}

	void setDiscount() {

	}
}
