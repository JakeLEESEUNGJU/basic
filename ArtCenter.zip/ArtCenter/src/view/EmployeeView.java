package view;

public class EmployeeView {

	public EmployeeView() {
		addLayout();
		connectDB();
		eventProc();
	}

	void eventProc() {

	}

	void addLayout() {

	}

	void connectDB() {

	}

	void insertEmp() {

	}

	void modifyEmp() {

	}

	void deleteEmp() {

	}

	void selectEmp() {

	}

	void clear() {

	}
}
