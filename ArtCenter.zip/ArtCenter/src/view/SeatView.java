package view;

public class SeatView {

	public SeatView() {
		addLayout();
		connectDB();
		eventProc();
	}

	void eventProc() {

	}

	void addLayout() {

	}

	void connectDB() {

	}

	void clickSeat() {

	}
}
