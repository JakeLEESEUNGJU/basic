package view;

public class ArtCenterView {

	public ArtCenterView() {
		addLayout();
		connectDB();
		eventProc();
	}

	void eventProc() {

	}

	void addLayout() {

	}

	void connectDB() {

	}
}
