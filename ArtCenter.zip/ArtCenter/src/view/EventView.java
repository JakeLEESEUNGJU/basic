package view;

public class EventView {

	public EventView() {
		addLayout();
		connectDB();
		eventProc();
	}

	void eventProc() {

	}

	void addLayout() {

	}

	void connectDB() {

	}

	void insertEvt() {

	}

	void modifyEvt() {

	}

	void deleteEvt() {

	}

	void selectEvt() {

	}

	void clear() {

	}
}
