package view;

public class TicketExhibitionView {

	public TicketExhibitionView() {
		addLayout();
		connectDB();
		eventProc();
	}

	void eventProc() {

	}

	void addLayout() {

	}

	void connectDB() {

	}

	void selectDate() {

	}
}
