package view;

public class TicketPerformanceView {

	public TicketPerformanceView() {
		addLayout();
		connectDB();
		eventProc();
	}

	void eventProc() {

	}

	void addLayout() {

	}

	void connectDB() {

	}

	void selectDate() {

	}
}
